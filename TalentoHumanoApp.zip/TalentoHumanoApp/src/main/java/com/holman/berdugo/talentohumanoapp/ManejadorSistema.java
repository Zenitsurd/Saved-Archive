package com.holman.berdugo.talentohumanoapp;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author reg
 */
public class ManejadorSistema {

    private ArrayList<Usuario> usuariosRegistrados;
    private Scanner entradaDatos;

    public ManejadorSistema() {
        this.usuariosRegistrados = new ArrayList<>();
        this.entradaDatos = new Scanner(System.in);
    }

    public Usuario loginUsuario() {
        
        System.out.println("*** Inicio de sesion ***");
        System.out.print("Usuario: ");
        String usuario = entradaDatos.nextLine();
        System.out.print("Contrasena: ");
        String contrasena = entradaDatos.nextLine();

        if (!usuario.isEmpty() && !contrasena.isEmpty()) { //Validamos que el usuario ingreso los datos

            for (Usuario usuarioData : usuariosRegistrados) {
                if (usuarioData.getUsuario().equals(usuario) && usuarioData.contrasena.equals(contrasena)) {
                    System.out.println("Inicio de sesion exitoso. \n");
                    return usuarioData;
                }
            }

            System.out.println("Credenciales incorrectas \n");
            return null;

        }

        System.out.println("Debe ingresar su usuario y/o contrasena \n");
        return null;
    }

    public void registrarUsuario() {
        // TODO: DESCOMENTAR ESTO CUANDO IMPLEMENTES LA LOGICA PARAS SOLICITAR LOS VALORES DENTRO DE ESTOS METODOS
        /*System.out.println("*** Registro de usuario ***");
        System.out.println("Tipo de usuario a registrar: ");
        System.out.println("1. Persona Natural");
        System.out.println("2. Empresa");*/

        // TODO: QUITAR ESTO CUANDO IMPLEMENTES LA LOGICA PARAS SOLICITAR LOS VALORES DENTRO DE ESTOS METODOS
        registrarPersonaNatural();
        registrarEmpresa();
        System.out.println("Usuarios registrados existosamente. \n");

        /*
        // int opcion = Integer.parseInt(entradaDatos.nextLine());
        // int opcion = entradaDatos.nextInt();
        
        switch(opcion) {
            case 1: 
                registrarPersonaNatural();
                break;
            case 2: 
                registrarEmpresa();
                break;
            default: 
                System.out.println("Opcion no valida");
                break;    
        }*/
    }

    public void mostrarUsuarios() {
        System.out.println("*** Usuarios Registrados ***");
        for (Usuario usuario : usuariosRegistrados) {
            usuario.verPerfil();
            System.out.println("\n");
        }
    }

    public void crearVacantes(Usuario usuario) {
        if (usuario instanceof Empresa) {
            Empresa empresa = (Empresa) usuario; // cast: forzar la conversion del contenido de usuario en un objeto de tipo empresa

            // solicitar valores de la vacante
            empresa.agregarVacante("vacante1", "descripcion de la vacante 1", 1200000);
        } else {
            System.out.println("Solo las empresas pueden crear vacante");
        }
    }

    public void verVacantes(Usuario usuario) {
        if (usuario instanceof PersonaNatural) {
            PersonaNatural persona = (PersonaNatural) usuario; // cast: forzar la conversion del contenido de usuario en un objeto de tipo persona natural

            System.out.println("*** Vacantes ***");

            boolean vacantesDisponible = false;

            for (Usuario u : usuariosRegistrados) {
                if (u instanceof Empresa) {
                    Empresa empresa = (Empresa) u;

                    System.out.println("Vacantes de la empresa " + empresa.getNombre());
                    empresa.mostrarVacantes();
                    vacantesDisponible = true;
                }
            }

            if (vacantesDisponible == false) {
                System.out.println("No hay vacantes disponibles en el momento.");
            }

        } else {
            System.out.println("Solo las personas pueden ver el listado de vacantes");
        }
    }

    private void registrarPersonaNatural() {
        // solicitar los valores
        

        // Usuario 1
        PersonaNatural usuario1 = new PersonaNatural(
                123456789, // identificacion
                "Juan Pérez", // nombre
                "juan.perez@email.com", // correo
                "3001234567", // telefono
                30, // edad
                "Colombiana", // nacionalidad
                "Masculino", // genero
                5, // aniosExperiencia
                "Desarrollador de software en Empresa X", // experienciaLaboral
                "usuario1", // usuario
                "123" // contrasena
        );

        // Usuario 2
        PersonaNatural usuario2 = new PersonaNatural(
                987654321, // identificacion
                "María López", // nombre
                "maria.lopez@email.com", // correo
                "3001234567", // telefono
                28, // edad
                "Argentina", // nacionalidad
                "Femenino", // genero
                3, // aniosExperiencia
                "Diseñadora gráfica en Agencia Y", // experienciaLaboral
                "usuario2", // usuario
                "123" // contrasena
        );

        usuariosRegistrados.add(usuario1);
        usuariosRegistrados.add(usuario2);
    }

    private void registrarEmpresa() {
        // solicitar los valores

        // Registro 1
        Empresa empresa1 = new Empresa(
                "Bogotá, Colombia", // ubicacion
                150, // numeroTrabajadores
                "Tecnología y desarrollo de software.", // descripcion
                "Proveer soluciones innovadoras que transformen la industria.", // mision
                "Ser la empresa líder en desarrollo de software en Latinoamérica.", // vision
                "Tech Innovations", // nombre
                "contacto@techinnovations.com", // correo
                "3001234567", // telefono
                "empresa1", // usuario
                "123" // contrasena
        );

        // Registro 2
        Empresa empresa2 = new Empresa(
                "Buenos Aires, Argentina", // ubicacion
                80, // numeroTrabajadores
                "Agencia de marketing digital.", // descripcion
                "Impulsar el crecimiento de nuestros clientes a través del marketing digital.", // mision
                "Ser la agencia de marketing más reconocida en Argentina.", // vision
                "Digital Growth", // nombre
                "info@digitalgrowth.com", // correo
                "3009876543", // telefono
                "empresa2", // usuario
                "123" // contrasena
        );

        usuariosRegistrados.add(empresa1);
        usuariosRegistrados.add(empresa2);
    }
}
