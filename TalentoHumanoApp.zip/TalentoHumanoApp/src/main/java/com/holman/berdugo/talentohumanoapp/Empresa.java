/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.holman.berdugo.talentohumanoapp;

import java.util.ArrayList;

/**
 *
 * @author reg
 */
public class Empresa extends Usuario {

    private String ubicacion;
    private int numeroTrabajadores;
    private String descripcion;
    private String mision;
    private String vision;
    private ArrayList<Vacante> vacantes;

    public Empresa(String ubicacion, int numeroTrabajadores, String descripcion, String mision, String vision,
            String nombre, String correo, String telefono, String usuario, String contrasena) {
        super(nombre, correo, telefono, usuario, contrasena);
        this.ubicacion = ubicacion;
        this.numeroTrabajadores = numeroTrabajadores;
        this.descripcion = descripcion;
        this.mision = mision;
        this.vision = vision;
        this.vacantes = new ArrayList<>();
    }

    @Override
    public void verPerfil() {
        if (perfilPublico) {
            System.out.println("Nombre: " + nombre);
            System.out.println("Correo: " + correo);
            // continua con los demás campos.
        } else {
            System.out.println("El perfil de esta empresa es privado.");
        }
    }

    public void agregarVacante(String titulo, String descripcion, double salario) {
        Vacante vacante = new Vacante();
        vacantes.add(vacante);
        System.out.println("Vacante creada exitosamente.");
    }

    public void mostrarVacantes() {
        if (vacantes.isEmpty()) {
            System.out.println("No hay vacantes publicadas.");
        } else {
            for(Vacante vacante: vacantes) {
                vacante.mostrarVacantes();
                System.out.println("\n");
            }
        }
    }

    // Getters y Setters
    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getNumeroTrabajadores() {
        return numeroTrabajadores;
    }

    public void setNumeroTrabajadores(int numeroTrabajadores) {
        this.numeroTrabajadores = numeroTrabajadores;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMision() {
        return mision;
    }

    public void setMision(String mision) {
        this.mision = mision;
    }

    public String getVision() {
        return vision;
    }

    public void setVision(String vision) {
        this.vision = vision;
    }

}
