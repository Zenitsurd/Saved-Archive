/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.holman.berdugo.talentohumanoapp;

/**
 *
 * @author reg
 */
public class PersonaNatural extends Usuario {
    private int identificacion;
    private int edad;
    private String nacionalidad;
    private String genero;
    private int aniosExperiencia;
    private String experienciaLaboral;

    public PersonaNatural(int identificacion, String nombre, String correo, String telefono, 
            int edad, String nacionalidad, String genero, int aniosExperiencia,
            String experienciaLaboral, String usuario, String contrasena) {
        super(nombre, correo, telefono, usuario, contrasena);
        
        this.identificacion = identificacion;
        this.edad = edad;
        this.nacionalidad = nacionalidad;
        this.genero = genero;
        this.aniosExperiencia = aniosExperiencia;
        this.experienciaLaboral = experienciaLaboral;
        
    }

    @Override
    public void verPerfil() {
        if(perfilPublico) {
            System.out.println("Identificacion: " + identificacion);
            System.out.println("Nombre: " + nombre);
            System.out.println("Correo: " + correo);
            // continua con los demás campos.
        } else {
            System.out.println("El perfil de este usuario es privado.");
        }
    }
    
    // Getters y Setters
    
    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAniosExperiencia() {
        return aniosExperiencia;
    }

    public void setAniosExperiencia(int aniosExperiencia) {
        this.aniosExperiencia = aniosExperiencia;
    }

    public String getExperienciaLaboral() {
        return experienciaLaboral;
    }

    public void setExperienciaLaboral(String experienciaLaboral) {
        this.experienciaLaboral = experienciaLaboral;
    }
}
