/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.holman.berdugo.talentohumanoapp;

/**
 *
 * @author reg
 */
public abstract class Usuario {
    
    // Atributos comunes
    protected String  nombre;
    protected String  correo;
    protected String  telefono;
    protected String  usuario;
    protected String  contrasena;
    protected boolean perfilPublico;
    
    public Usuario(String nombre, String correo, String telefono, String usuario, String contrasena){
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.perfilPublico = true; //false
    }
    
    /* Métodos comunes, setters y getters */
    
    // abstract para que cada clase hija lo implemente a su manera
    public abstract void verPerfil();
    
    public void cambiarVisibilidadPerfil(boolean publico) {
        this.perfilPublico = publico;
    }
    
    /* Getters */    

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getUsuario() {
        return usuario;
    }

    public boolean isPerfilPublico() {
        return perfilPublico;
    }
}
