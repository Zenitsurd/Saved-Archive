/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.holman.berdugo.talentohumanoapp;

import java.util.Scanner;

/**
 *
 * @author reg
 */
public class TalentoHumanoApp {

    public static void main(String[] args) {
        ManejadorSistema sistema = new ManejadorSistema();

        Usuario usuarioLogueado = null;
        boolean salir = false;
        Scanner entradaDatos = new Scanner(System.in);

        while (!salir) {

            System.out.println("*** Menu ***");
            System.out.println("1. Registrar usuario");
            System.out.println("2. Listar usuarios registrados");
            System.out.println("3. Iniciar sesion");
            System.out.println("4. Crear Vacante (Solo aplica para empresas)");
            System.out.println("5. Ver vacantes disponibles (Solo aplica para personas)");
            System.out.println("0. Salir");

            int opcion = entradaDatos.nextInt();

            // System.out.println(opcion);

            // TODO: Pendiente implementar la opción de ir atras desde los submodulos.
            switch (opcion) {
                case 1:
                    sistema.registrarUsuario();
                    break;
                case 2:
                    sistema.mostrarUsuarios();
                    break;
                case 3:
                    usuarioLogueado = sistema.loginUsuario();
                    if (usuarioLogueado != null) {
                        System.out.println("Bienvenido " + usuarioLogueado.getNombre());
                    }
                    break;
                case 4:
                    if (usuarioLogueado != null && usuarioLogueado instanceof Empresa) {
                        sistema.crearVacantes(usuarioLogueado);
                    } else {
                        System.out.println("Debe iniciar sesion como empresa para crear vacante.");
                    }
                    break;
                case 5:
                    if (usuarioLogueado != null && usuarioLogueado instanceof PersonaNatural) {
                        sistema.verVacantes(usuarioLogueado);
                    } else {
                        System.out.println("Debe iniciar sesion como persona para ver vacante.");
                    }
                    break;
                case 0:
                    salir = true;
                    System.out.println("Cerrando la aplicacion...");
                    break;
                default:
                    System.out.println("Opcion no valida.");
                    break;
            }

        }
    }
}
