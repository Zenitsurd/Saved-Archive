/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.holman.berdugo.talentohumanoapp;

/**
 *
 * @author reg
 */
public class Vacante {
    private String titulo;
    private String descripcion;
    private double salario;
    
    public void mostrarVacantes(){
        System.out.println("Titulo: "+ titulo);
        System.out.println("Descripcion: "+ descripcion);
        System.out.println("Salario: "+ salario);
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}
