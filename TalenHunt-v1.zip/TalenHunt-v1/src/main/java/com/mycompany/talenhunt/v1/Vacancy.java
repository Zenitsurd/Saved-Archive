
package com.mycompany.talenhunt.v1;

import java.util.ArrayList;
public class Vacancy {
    
    public static int id = 0;
    private String titleVacancy;
    private String puestoVacante; //pasar a ingles
    private String descriptionVacancy;
    private String academicTraining;
    private String experience;
    //Habilidades blandas y duras
    private String workingDay;
    private double salary;
    private String location;
    private String benefits;
    private String deadline;
    private String contact;
    private String typeOfContract;
    private boolean publicVacan;
    private ArrayList<Person> postulantes; //a ingles
    
    public Vacancy(String titleVacancy, String puestoVacante,String descriptionVacancy, String academicTraining, String experience, String workingDay,
            double salary, String location, String benefits, String deadline, String contact, String typeOfContract){
        this.titleVacancy = titleVacancy;
        this.puestoVacante = puestoVacante;
        this.descriptionVacancy = descriptionVacancy;
        this.academicTraining = academicTraining;
        this.experience = experience;
        this.workingDay = workingDay;
        this.salary = salary;
        this.location = location;
        this.benefits = benefits;
        this.deadline = deadline;
        this.contact = contact;
        this.typeOfContract = typeOfContract;
        this.publicVacan = false;
        this.postulantes = new ArrayList<>();
        id++;
    }
    
    //Getters
    public String getTitleVacancy(){
        return titleVacancy;
    }
    
    public String getPuestoVacancy(){ //pasar a ingles
        return puestoVacante;
    } 
            
    public int getIdVacancy(){
        return id;
    }
    
    public boolean getPublicVacan(){
        return publicVacan;
    }
    
    //Setters
    public void setPublicVacancy(boolean stateVacancy){
        this.publicVacan = stateVacancy;
    }
    
    //metodo para agregar postulantes
    public void addPostulantes(Person person){
        this.postulantes.add(person);
    }
}
