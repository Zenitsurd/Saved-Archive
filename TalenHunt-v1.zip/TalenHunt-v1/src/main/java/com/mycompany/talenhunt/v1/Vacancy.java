package com.mycompany.talenhunt.v1;

import java.util.ArrayList;

public class Vacancy {

    //atributos de clase
    private static int idCount = 0; //contador que le pertenece a la clase para crear un id de vacante
    private int idVacancy; //Guardamos idCount para que le pertenezca al objeto
    private String titleVacancy;
    private String positionVacancy; //puesto que ocupara el postulante en la empresa
    private String descriptionVacancy;
    private String academicTraining; //formacion academica
    private String workExperience;
    private String workingDay; //jornada laboral
    private double salary;
    private String location;
    private String benefits;
    private String contact;
    private String typeOfContract;
    private boolean publicVacan;
    private ArrayList<Person> applicants;

    public Vacancy(String titleVacancy, String positionVacancy, String descriptionVacancy, String academicTraining, String workExperience, String workingDay,
            double salary, String location, String benefits, String contact, String typeOfContract) {
        this.titleVacancy = titleVacancy;
        this.positionVacancy = positionVacancy;
        this.descriptionVacancy = descriptionVacancy;
        this.academicTraining = academicTraining;
        this.workExperience = workExperience;
        this.workingDay = workingDay;
        this.salary = salary;
        this.location = location;
        this.benefits = benefits;
        this.contact = contact;
        this.typeOfContract = typeOfContract;
        this.publicVacan = false;
        this.applicants = new ArrayList<>();
        idCount++;
        this.idVacancy = idCount;
    }

    //Getters
    public int getIdVacancy() {
        return idVacancy;
    }

    public boolean getPublicVacancy() {
        return publicVacan;
    }

    //Setters
    public void setPublicVacancy(boolean stateVacancy) {
        this.publicVacan = stateVacancy;
    }

    //Agregar postulantes
    public void addApplicants(Person person) {
        this.applicants.add(person);
    }

    //valiidar que ya esta postulado a la vacante
    public boolean isPostulated(Person person, int id) {

        //recorremos la lista de postulantes
        for (Person applicant : applicants) {
            
            //validamos que la persona no este postulada a una vacante con el id para saber a que vacante
            if (id == idVacancy && person.getId() == applicant.getId() && publicVacan) {
                return true;
            }
        }
        
        return false;
    }

    //listar vacantes
    public String listVacancy() {
        
        return "Titulo de la vacante | " + titleVacancy + "\nIdentificador : " + idVacancy + "| Puesto de vacante : "
                + positionVacancy + "\n";
        
    }

    //mostrar postulantes a vacante
    public void viewApplicants() {

        if (!applicants.isEmpty()) {
            for (Person applicant : applicants){
                System.out.println(applicant.viewProfile());
            }
        } else {
            System.out.println("\nNo hay postulantes para esta vacante");
        }
    }

    //mostramos los datos de la vacante
    @Override
    public String toString() {
        return "Titulo de vacante | " + titleVacancy + "\nPuesto de vacante | " + positionVacancy
                + "\nDescripcion de vacante | " + descriptionVacancy + "\nFormacion academica | " + academicTraining
                + "\nExperiencia laboral | " + workExperience + "\nJornada laboral : " + workingDay + " | Salario : "
                + salary + "\nUbicacion | " + location + "\nBeneficios | " + benefits + "\nContacto : " + contact
                + " | Tipo de contrato : " + typeOfContract + " | Identificador : " + idVacancy + "\n";
    }
}
