package com.mycompany.talenhunt.v1;

import java.util.ArrayList;

public class Company extends Users {

    //Atributos clase empresa
    private String location;
    private int numEmployees;
    private String descriptionCompany;
    private String missionCompany;
    private String visionCompany;
    private ArrayList<Vacancy> vacancies;

    //Metodo constructor de la clase empresa
    public Company(String user, String password, String name, String mail, String phoneNumber,
            String location, int numEmployees, String descriptionCompany, String missionCompany, String visionCompany) {
        super(user, password, name, mail, phoneNumber);
        this.location = location;
        this.numEmployees = numEmployees;
        this.descriptionCompany = descriptionCompany;
        this.missionCompany = missionCompany;
        this.visionCompany = visionCompany;
        this.vacancies = new ArrayList<>();
    }

    //Ver perfil (siento que deberia retornar y no imprirmir)
    @Override
    public void viewProfile() {
        //Al terminar modificar esto de una manera mas flexible
        System.out.println("Nombre | " + name);
        System.out.println("Email | " + mail);
        System.out.println("Numero de telefono | " + phoneNumber);
        System.out.println("Ubicacion | " + location);
        System.out.println("Numero de empleados | " + numEmployees);
        System.out.println("Descripcion de la empresa | " + descriptionCompany);
        System.out.println("Mision | " + missionCompany);
        System.out.println("Vision | " + visionCompany);
    }

    //Crear vacante
    public void addVacancies(Vacancy vacancies) {
        this.vacancies.add(vacancies);
    }

    //validamos que la empresa tenga vacantes
    public boolean isVacancy() {
        if (!vacancies.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    //Listamos las vacantes que tiene la empresa
    public void listarVacantes() { //ingles
        for (Vacancy vacancy : vacancies) {
            System.out.println("Titulo de vacante " + vacancy.getTitleVacancy());
            System.out.println("identificador: " + vacancy.getIdVacancy() + " Puesto de la vacante: " + vacancy.getPuestoVacancy());
        }
    }

    //metodo para validar que el id ingresado sea de una vacante de la empresa
    public void validateId(int id) {
        for (Vacancy vacancy : vacancies) {
            if (id == vacancy.getIdVacancy()) {
                if (vacancy.getPublicVacan() != true) {
                    vacancy.setPublicVacancy(true);
                    System.out.println("Su vacante se ha publicado");
                } else {
                    System.out.println("No puede publicar dos veces la misma vacante");
                }
            }
        }
    }

    //ver mis vacantes
    public void viewMyVacancies() {
        for (Vacancy vacancy : vacancies) {
            System.out.println("Titulo de vacante " + vacancy.getTitleVacancy());
        }
    }

    //Mostrar vacantes publicas (para personas)
    public void mostrarVacancies() { //ingles
        for (Vacancy vacancy : vacancies) {

            if (vacancy.getPublicVacan() == true) {
                System.out.println("Titulo de vacante " + vacancy.getTitleVacancy());
            }
        }
    }

    //listar datos importantes a la persona para que pueda postularse
    public void listarVacantesAPersonas() { //ingles
        for (Vacancy vacancy : vacancies) {
            System.out.println("Titulo de vacante " + vacancy.getTitleVacancy());
            System.out.println("identificador: " + vacancy.getIdVacancy() + " Puesto de la vacante: " + vacancy.getPuestoVacancy());
        }
    }

    //Buscar vacante
    public Vacancy vacanteEncontrada(int id) {

        Vacancy vacanteEncontrada = null;

        for (Vacancy vacancy : vacancies) {
            if (vacancy.getIdVacancy() == 1) {
                vacanteEncontrada = vacancy;
                break;
            }
        }
        return vacanteEncontrada;
    }
}
