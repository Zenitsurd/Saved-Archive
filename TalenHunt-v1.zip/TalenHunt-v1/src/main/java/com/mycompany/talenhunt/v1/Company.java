package com.mycompany.talenhunt.v1;

import java.util.ArrayList;

public class Company extends Users {

    //Atributos de clase
    private String location;
    private int numEmployees;
    private String descriptionCompany;
    private String missionCompany;
    private String visionCompany;
    private ArrayList<Vacancy> vacancies;

    //Metodo constructor
    public Company(String user, String password, String name, String mail, String phoneNumber,
            String location, int numEmployees, String descriptionCompany, String missionCompany,
            String visionCompany) {

        super(user, password, name, mail, phoneNumber);
        this.location = location;
        this.numEmployees = numEmployees;
        this.descriptionCompany = descriptionCompany;
        this.missionCompany = missionCompany;
        this.visionCompany = visionCompany;
        this.vacancies = new ArrayList<>();
    }

    //Perfil
    //Ver perfil (implementando metodo de la clase abstracta Users)
    @Override
    public String viewProfile() {

        return "Nombre : " + name + " | Email : " + mail + " | Numero de telefono : " + phoneNumber
                + "\nUbicacion : " + location + " | Numero de empleados : " + numEmployees + "\nDescripcion de la empresa | "
                + descriptionCompany + "\nMision | " + missionCompany + "\nVision | " + visionCompany;
    }

    //Vacantes
    //agregamos vacantes al array
    public void addVacancies(Vacancy vacancies) {

        this.vacancies.add(vacancies);

    }

    //validamos que la empresa tenga vacantes
    public boolean validateVacancies() {

        if (!vacancies.isEmpty()) { //si array de vacantes no esta vacio
            return true;
        } else {
            return false;
        }

    }

    //Listamos las vacantes que tiene la empresa
    public void listMyVacancies() {

        for (Vacancy vacancy : vacancies) {
            System.out.println(vacancy.listVacancy());
        }

    }

    //metodo para validar que el id ingresado sea de una vacante de la empresa y publicarla
    public boolean validatePublicVacancy(int id) {

        boolean idValidate = false;

        //recorremos el array de vacantes
        for (Vacancy vacancy : vacancies) {

            // validamos si el id ingresado es igual al de una vacante del array
            if (id == vacancy.getIdVacancy()) {

                idValidate = true;

                //Validamos que la vacante no este publicada
                if (vacancy.getPublicVacancy() != true) {
                    //publicamos vacante
                    vacancy.setPublicVacancy(true);
                    System.out.println("\nSu vacante se ha publicado");
                    break;

                } else {

                    //si esta publicada (es false) imprime lo sgte
                    System.out.println("\nNo puede publicar dos veces la misma vacante");
                    break;
                }
            } else {
                //si no hay ninguna vacante con este id cambiamos a false para saber que no hay
                idValidate = false;
            }
        }

        return idValidate;
    }

    //ver mis vacantes
    public void viewMyVacancies() {

        for (Vacancy vacancy : vacancies) {

            System.out.println(vacancy.toString());

        }

    }

    //Mostrar vacantes publicas (para personas)
    public String showVacancies(int id) {

        //recorremos el array de vacante
        for (Vacancy vacancy : vacancies) {

            if (id == vacancy.getIdVacancy()) {
                if (vacancy.getPublicVacancy()) {
                    return vacancy.toString();
                }
            }
        }

        return null;
    }

    //listar datos importantes a la persona para que pueda postularse
    public boolean listVacancyToPerson() {

        boolean isVacancyPublic = false; //para guardar y saber si hay vacantes publicas

        for (Vacancy vacancy : vacancies) {

            //validamos que la vacante este publicada
            if (vacancy.getPublicVacancy() != false) {

                System.out.println("Vacante de la empresa: " + name + "\n");
                System.out.println(vacancy.listVacancy());
                isVacancyPublic = true;

            }
        }

        return isVacancyPublic;
    }

    //agregar postulantes
    public String applicantsVacancy(int id, Person person) {

        for (Vacancy vacancy : vacancies) {

            //Validamos que el id ingresado sea igual al de una vacante creada
            if (vacancy.getIdVacancy() == id) {

                if (vacancy.getPublicVacancy()) {

                    //si el retorno de la vacante no es true
                    if (!vacancy.isPostulated(person, id)) {

                        vacancy.addApplicants(person);
                        return "\nSe ha postulado con exito a la vacante";
                    }
                }
            }
        }
        return "\nNo hay una vacante con este id o no esta publicada";
    }

    //validamos que la persona no se postule dos veces a una misma vacante
    public boolean validatePostulate(Person person, int id) {

        for (Vacancy vacancy : vacancies) {
            if (vacancy.isPostulated(person, id)) {
                return true;
            }
        }

        return false;
    }

    //ver postulantes
    public boolean viewApplicantsOfVacancy(int id) {

        boolean validateId = false;

        for (Vacancy vacancy : vacancies) {
            if (id == vacancy.getIdVacancy()) {
                vacancy.viewApplicants();
                validateId = true;
            }
        }

        return validateId;
    }
}
