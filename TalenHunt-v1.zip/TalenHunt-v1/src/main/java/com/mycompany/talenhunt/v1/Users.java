
package com.mycompany.talenhunt.v1;

public abstract class Users {
    
    //Atributos que tienen en comun personas y empresas
    protected String user;
    protected String password;
    protected String name;
    protected String mail;
    protected String phoneNumber;
    protected boolean publishedProfile;
    
    //Este es el constructor
    public Users(String user, String password, String name, String mail, String phoneNumber){
        this.user = user;
        this.password = password;
        this.name = name;
        this.mail = mail;
        this.phoneNumber = phoneNumber;
        this.publishedProfile = false;
    }
    
    //metodo en comun de ambas clases (cada clase hija lo implementa a su manera)
    public abstract void viewProfile();
    
    //Getters and setters
    
    //Getters
    public String getUser(){
        return user;
    }
    
    public String getPassword(){
        return password;
    }
    
    public String getName(){
        return name;
    }
    
    public boolean getPublishedProfile(){
        return publishedProfile;
    }
    
    
    //Setters
    public void setPublicProfile(boolean publish){
        this.publishedProfile = publish;
    }
    
}
