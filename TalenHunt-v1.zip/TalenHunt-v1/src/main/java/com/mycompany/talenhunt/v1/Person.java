
package com.mycompany.talenhunt.v1;

public class Person extends Users{
    
    //Atributos de clase persona
    private int age;
    private String nationality;
    private String gender;
    private int yearWorkExperience;
    private String workExperience;
    private int idPerson;

    //metodo constructor de clase persona
    public Person(String user, String password, String name, String mail, String phoneNumber,int age,
            String nationality, String gender, int yearWorkExperience, String workExperience, int idPerson){
        super(user, password, name, mail, phoneNumber);
        this.age = age;
        this.nationality = nationality;
        this.gender = gender;
        this.yearWorkExperience = yearWorkExperience;
        this.workExperience = workExperience;
        this.idPerson = idPerson;
    }
    
    //@Override se usa para saber que un metodo se esta sobreescribiendo
    //Ver perfil
    @Override
    public void viewProfile(){
        //Al terminar modificar esto de una manera mas flexible
        System.out.println("Nombre | " + name);
        System.out.println("Email | " + mail);
        System.out.println("Numero de telefono | " + phoneNumber);
        System.out.println("Edad | " + age);
        System.out.println("Nacionalidad | " + nationality);
        System.out.println("Genero | " + gender);
        System.out.println("Años de experiencia laboral | " + yearWorkExperience);
        System.out.println("Experiencia laboral | " + workExperience);
        System.out.println("Numero de identificacion | " + idPerson);
    }
    
    //Mostrar vacantes disponibles
    public void showVacanciesAvailable(){
        
    }
    
    //Aplicar a vacantes (Postularse)
    public void applyToVacancies(){
    }
}
