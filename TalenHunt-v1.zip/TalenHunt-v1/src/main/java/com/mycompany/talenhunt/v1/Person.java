package com.mycompany.talenhunt.v1;

//Esta clase hereda de la clase usuarios (Users)
public class Person extends Users {

    //Atributos de clase
    private static int idCount= 0; //El static hace que cada vez que se llame al constructor 
    //se cree un id que le pertenece en si a la clase y no al objeto
    private int id; //Variable para contener el identificador generado
    private String title;
    private int age;
    private String nationality;
    private String gender;
    private int yearWorkExperience;
    private String workExperience;
    private int identiPerson; //numero de identificacion

    //metodo constructor de clase persona
    public Person(String user, String password, String name, String mail,String phoneNumber,String title, int age,
            String nationality, String gender, int yearWorkExperience, String workExperience, int idPerson) {
        super(user, password, name, mail, phoneNumber); //se llama al constructor de la clase Users
        this.title = title;
        this.age = age;
        this.nationality = nationality;
        this.gender = gender;
        this.yearWorkExperience = yearWorkExperience;
        this.workExperience = workExperience;
        this.identiPerson = idPerson;
        idCount++; //incrementamos el identificador cada vez que se llame al constructor
        this.id = idCount; //almacenamos el id para que sea del objeto
    }

    //getters
    public int getId() {
        return id;
    }

    //@Override se usa para saber que un metodo se esta sobreescribiendo
    @Override
    //Ver perfil (sobreescribimos el metodo viewProfile de la clase Users)
    public String viewProfile() {
        
        return "Nombre : " + name + " | Email : " + mail + " | Numero de telefono : " + phoneNumber
                + "\nEdad : " + age + " | Nacionalidad : " + nationality + " | Genero : " + gender
                + " | Años de experiencia laboral : " + yearWorkExperience + "\nExperiencia laboral | "
                + workExperience + "\nNumero de identificacion | " + identiPerson + "\nTitulo(s) | " + title;
    }
    
    //Editar perfil
}
