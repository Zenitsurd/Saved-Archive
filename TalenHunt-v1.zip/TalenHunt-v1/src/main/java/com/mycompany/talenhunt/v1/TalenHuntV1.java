//Se recomienda usar el jdk 17 para evitar errores en el programa

package com.mycompany.talenhunt.v1;

import java.util.Scanner;

public class TalenHuntV1 {

    public static void main(String[] args) {

        //Objetos
        Scanner input = new Scanner(System.in);
        Menu menu = new Menu();
        SystemManager manager = new SystemManager();

        //Mantenemos el programa encendido
        while (true) {

            int option = 0;

            try {
                menu.menuMain();
                option = Integer.parseInt(input.nextLine());

            } catch (NumberFormatException ex) {
                System.out.println("\nIngrese solo numeros porfavor");
            }

            if (option != 0) {
                switch (option) {
                    case 1:
                        //Inicio de sesion
                        manager.actionUsers();
                        break;
                    case 2:
                        //Registrar usuario
                        manager.registeredUsers();
                        break;
                    case 3:
                        //salir
                        System.out.println("Bye bye");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("\nOpcion no valida. Intentelo nuevamente");
                        break;
                }

            }
        }
    }
}
