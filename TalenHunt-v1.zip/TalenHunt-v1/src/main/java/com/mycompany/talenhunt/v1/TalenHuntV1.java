package com.mycompany.talenhunt.v1;

import java.util.Scanner;

public class TalenHuntV1 {

    public static void main(String[] args) {

        //Objetos
        Scanner input = new Scanner(System.in);
        Menu menu = new Menu();
        SystemManager manager = new SystemManager();
        Users userLogued = null;

        //Mantenemos el programa encendido
        while (true) {

            menu.menuMain();

            int option = Integer.parseInt(input.nextLine());

            switch (option) {
                case 1:
                    //Guardamos los datos del usuario que se logueo
                    userLogued = manager.loginUsers();

                    //validamos que el usuario ingresado sea valido
                    if (userLogued != null) {
                        //instance of para saber de que clase es este objeto
                        if (userLogued instanceof Person) {
                            System.out.println("Bienvenido " + userLogued.getName());
                            manager.actionPerson(userLogued);
                        } else if (userLogued instanceof Company) {
                            System.out.println("Bienvenido " + userLogued.getName());
                            manager.actionCompany(userLogued);
                        }
                    } else {
                        //Usuario no valido
                    }
                    break;
                case 2:
                    //Registrar usuario
                    manager.registeredUsers();
                    break;
                case 3:
                    //salir
                    System.out.println("Bye bye");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opcion no valida. Intentelo nuevamente");
                    break;
            }
        }
    }
}
