package com.mycompany.talenhunt.v1;

import java.util.ArrayList;
import java.util.Scanner;

public class SystemManager {

    //Atributos
    private ArrayList<Users> registeredUsers;
    private Scanner input;
    private Menu menu = new Menu();

    //Metodo constructor
    public SystemManager() {
        this.registeredUsers = new ArrayList<>();
        this.input = new Scanner(System.in);
    }

    //Login
    public Users loginUsers() {
        //usuarios personas
        Person person1 = new Person(
                "userP1", "password123", "Alice Johnson", "alice.johnson@example.com",
                "1234567890", 30, "American", "Female", 5,
                "Software Developer at TechCorp, Project Manager at InnovateX", 1
        );

        Person person2 = new Person(
                "userP2", "pass456", "Carlos Martínez", "carlos.martinez@example.com",
                "0987654321", 28, "Mexican", "Male", 3,
                "Data Analyst at DataVision, Junior Data Scientist at InsightsLab", 2
        );

        Person person3 = new Person(
                "userP3", "password789", "Emma Li", "emma.li@example.com",
                "1122334455", 35, "Chinese", "Female", 8,
                "Senior UX Designer at CreateSpace, Lead Designer at PixelPerfect", 3
        );

        registeredUsers.add(person1);
        registeredUsers.add(person2);
        registeredUsers.add(person3);

        //usuarios empresas
        Company company1 = new Company(
                "user1",
                "password1",
                "Tech Solutions",
                "contact@techsolutions.com",
                "1234567890",
                "New York, USA",
                50,
                "We provide cutting-edge tech solutions.",
                "Empower innovation",
                "Become a global leader in tech."
        );

        Company company2 = new Company(
                "user2",
                "password2",
                "Green Energy Co.",
                "info@greenenergy.com",
                "0987654321",
                "San Francisco, USA",
                200,
                "Leading provider of renewable energy solutions.",
                "Sustainable energy for all",
                "Transform the world with green energy."
        );
        Company company3 = new Company(
                "user3",
                "password3",
                "Health Plus",
                "support@healthplus.com",
                "1122334455",
                "Chicago, USA",
                100,
                "Innovative health services for everyone.",
                "Care beyond boundaries",
                "Promote health and wellness worldwide."
        );

        //Guardamos los datos de la empresa
        registeredUsers.add(company1);
        registeredUsers.add(company2);
        registeredUsers.add(company3);

        //Recopilamos datos
        System.out.println("Iniciar Sesion \n");
        System.out.print("Usuario: ");
        String user = input.nextLine();
        System.out.print("Contrasena: ");
        String password = input.nextLine();

        if (!user.isEmpty() && !password.isEmpty()) { //Validamos que el usuario ingreso datos validos

            for (Users userData : registeredUsers) { //recorremos la lista para hacer la validacion de usuarios

                //Validamos de que usuario ingresado sea igual a algun usuario de la lista y lo mismo con el password
                if (userData.getUser().equals(user) && userData.getPassword().equals(password)) {
                    // si se cumple la condicion return los datos de este usuario
                    return userData;
                }
            }

            //si el usuario ingresado no existe en la lista entonces las credenciales son erroneas o el usuario no existe
            System.out.println("Credenciales incorrectas \n");
            return null;

        } else {

            System.out.println("Debe ingresar su usuario y/o contrasena \n");
            return null;
        }
    }

    //Acciones que realiza la empresa
    public void actionCompany(Users user) {

        int on = 0;

        while (on != 4) {
            menu.menuCompany();
            System.out.print("Opcion: ");
            int option = Integer.parseInt(input.nextLine());

            switch (option) {

                case 1:
                    int on2 = 0;

                    while (on2 != 3) {
                        menu.menuProfile();
                        System.out.print("Opcion: ");
                        int option1 = Integer.parseInt(input.nextLine());

                        if (option1 == 1) {
                            viewMyProfileCompany(user);
                            on2 = 1;
                        } else if (option1 == 2) {
                            publishedProfileCompany(user);
                            on2 = 2;
                        } else if (option1 == 3) {
                            System.out.println("Volviendo al menu principal.");
                            on2 = 3;
                        } else {
                            System.out.println("Opcion no valida");
                        }

                    }
                    on = 1;
                    break;
                case 2:

                    int on3 = 0;

                    while (on3 != 4) {
                        menu.menuVacantCompany();
                        System.out.print("Opcion: ");
                        int option2 = Integer.parseInt(input.nextLine());

                        if (option2 == 1) {
                            createVacancy(user);
                            on3 = 1;
                        } else if (option2 == 2) {
                            publishedVacancy(user);
                            on3 = 2;
                        } else if (option2 == 3) {
                            viewMyVacancies(user);
                            on3 = 3;
                        } else if (option2 == 4) {
                            System.out.println("Volviendo al menu principal");
                            on3 = 4;
                        } else {
                            System.out.println("Opcion no valida");
                        }
                    }
                    on = 2;
                    break;
                case 3:
                    viewProfilePerson(user);
                    on = 3;
                    break;
                case 4:
                    //salir
                    on = 4;
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        }
    }

    //Acciones que realiza la persona
    public void actionPerson(Users user) {

        int on = 0;

        while (on != 4) {
            menu.menuPerson();
            System.out.print("Opcion: ");
            int option = Integer.parseInt(input.nextLine());

            switch (option) {
                case 1:

                    int on2 = 0;

                    while (on2 != 3) {
                        menu.menuProfile();
                        System.out.print("Opcion: ");
                        int option1 = Integer.parseInt(input.nextLine());

                        if (option1 == 1) {
                            viewMyProfilePerson(user);
                            on2 = 1;
                        } else if (option1 == 2) {
                            publishedProfilePerson(user);
                            on2 = 2;
                        } else if (option1 == 3) {
                            System.out.println("Volviendo al menu principal.");
                            on2 = 3;
                        } else {
                            System.out.println("Opcion no valida");
                        }
                    }
                    on = 1;
                    break;
                case 2:

                    int on3 = 0;

                    while (on3 != 3) {
                        menu.menuVacantPerson();
                        System.out.print("Opcion: ");
                        int option2 = Integer.parseInt(input.nextLine());

                        if (option2 == 1) {
                            viewVacancyAvailable(user);
                            on3 = 1;
                        } else if (option2 == 2) {
                            postulation(user);
                            on3 = 2;
                        } else if (option2 == 3) {
                            System.out.println("Volviendo al menu principal");
                            on3 = 3;
                        } else {
                            System.out.println("Opcion no valida");
                        }
                    }
                    on = 2;
                    break;
                case 3:
                    viewProfileCompany(user);
                    on = 3;
                    break;
                case 4:
                    on = 4;
                    //salir
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        }
    }

    //empresas
    //Perfil
    //ver perfil (empresa)
    public void viewMyProfileCompany(Users user) {
        if (user instanceof Company) {
            Company company = (Company) user;
            //ver perfil
            company.viewProfile();
        }
    }

    //Publicar perfil (empresa)
    public void publishedProfileCompany(Users user) {
        if (user instanceof Company) {
            Company company = (Company) user;
            //publicar perfil
            if (company.getPublishedProfile() != true) {
                company.setPublicProfile(true);
                System.out.println("Su perfil ha sido publicado");
            } else {
                System.out.println("No puedes publicar tu perfil, si ya ha sido publicado");
            }

        }
    }

    //Vacantes
    //Metodo para crear (Vacantes) - empresas
    public void createVacancy(Users user) {

        Company company = (Company) user;
        //Crear mis vacantes
        System.out.println("Creando vacante");
        System.out.print("Titulo de vacante: ");
        String titleVacancy = input.nextLine();
        System.out.print("Puesto de vacante: ");
        String puestoVacante = input.nextLine(); //pasar puesto vacante a ingles
        System.out.print("Descripcion de vacante: ");
        String descriptionCompany = input.nextLine();
        System.out.print("");// academicTraining
        String academicTraining = input.nextLine();
        System.out.print("Experiencia laboral: ");
        String experience = input.nextLine();
        System.out.print(""); //workingDay
        String workingDay = input.nextLine();
        System.out.print("Salario: ");
        double salary = Double.parseDouble(input.nextLine());
        System.out.print("Ubicacion: ");
        String location = input.nextLine();
        System.out.print("Beneficios : ");
        String benefits = input.nextLine();
        System.out.print(""); //deadLine
        String deadline = input.nextLine();
        System.out.print("Contacto: ");
        String contact = input.nextLine();
        System.out.print("Tipo de contrato: ");
        String typeOfContract = input.nextLine();

        Vacancy vacancy = new Vacancy(
                titleVacancy,
                puestoVacante,
                descriptionCompany,
                academicTraining,
                experience,
                workingDay,
                salary,
                location,
                benefits,
                deadline,
                contact,
                typeOfContract
        );

        //cast
        //Forzamos el contenido de usuario a convertirse en un objeto de la clase persona
        company.addVacancies(vacancy);

    }

    //metodo para publicar vacantes (empresa)
    public void publishedVacancy(Users user) {

        Company company = (Company) user;

        //Publicar vacantes
        System.out.println("Publicar vacante");

        if (company.isVacancy() == true) {
            company.listarVacantes();//ingles

            System.out.print("Ingrese el id de la vacante que desea publicar: ");
            int id = Integer.parseInt(input.nextLine());

            company.validateId(id);
        } else {
            System.out.println("No puede publicar vacantes si no ha creado una");
        }

    }

    //Metodo vara ver vacantes (empresa)
    public void viewMyVacancies(Users user) {

        if (user instanceof Company) {
            Company company = (Company) user;
            if (company.isVacancy() == true) {
                System.out.println("Esta viendo sus vacantes");
                company.viewMyVacancies();
            } else {
                System.out.println("No puede ver vacantes si no ha creado una");
            }
        }
    }

    //Perfiles de personas
    //Metodo para ver perfiles de personas (empresa)
    public void viewProfilePerson(Users user) {

        boolean availableProfile = false;

        for (Users users : registeredUsers) {
            if (users instanceof Person) {
                Person person = (Person) users;
                if (person.getPublishedProfile() == true) {
                    person.viewProfile();
                    availableProfile = true;
                }
            }
        }

        if (availableProfile == false) {
            System.out.println("No hay perfiles publicados");
        }
    }

    //Personas
    //Perfil
    //ver perfil (persona)
    public void viewMyProfilePerson(Users user) {
        if (user instanceof Person) {
            Person person = (Person) user;
            //ver perfil
            person.viewProfile();

        }
    }

    //Publicar perfil (persona)
    public void publishedProfilePerson(Users user) {
        if (user instanceof Person) {
            Person person = (Person) user;

            //publicar perfil
            //validamos que el perfil no este publicado
            if (person.getPublishedProfile() != true) {
                person.setPublicProfile(true);
                System.out.println("Su perfil ha sido publicado");
            } else {
                System.out.println("No puedes publicar tu perfil si ya ha sido publicado");
            }
        }
    }

    //Vacantes
    //Vacantes disponibles
    public void viewVacancyAvailable(Users user) {
        System.out.println("*** Vacantes ***");

        boolean availableVacancies = false;

        for (Users users : registeredUsers) {
            Company company = (Company) users;

            if (company.isVacancy() == true) {
                System.out.println("Nombre de la empresa " + company.getName());
                company.mostrarVacancies();
                availableVacancies = true;
            }

        }

        if (availableVacancies == false) {
            System.out.println("Por ahora no hay vacantes disponibles");
        }
    }

    //Postularse
    public void postulation(Users user) {
        Person person = (Person) user;
        boolean availableVacancy = false;

        System.out.println("Postularse");

        for (Users users : registeredUsers) {
            if (users instanceof Company) {
                Company company = (Company) users;

                if (company.isVacancy() != false) {
                    System.out.println("Vacante de la empresa: " + company.getUser());
                    company.listarVacantesAPersonas();
                    availableVacancy = true;
                }
            }
        }

        if (availableVacancy != false) {
            System.out.print("Ingrese el id de la vacante: ");
            int id = Integer.parseInt(input.nextLine());

            Vacancy vacante = null;

            for (Users users : registeredUsers) {
                if (users instanceof Company) {
                    Company company = (Company) users;

                    vacante = company.vacanteEncontrada(id);

                }
            }

            if (vacante == null) {
                System.out.println("Esta vacante no existe");
            } else {
                vacante.addPostulantes(person);
                System.out.println("Se ha postulado con exito a la vacante");
            }
        } else {
            System.out.println("Por el momento no hay vacantes disponibles");
        }
    }

    //Ver perfiles de empresas
    //metodo para ver perfiles de empresas (PERSONAS)
    public void viewProfileCompany(Users user) {
        if (user instanceof Person) {
            for (Users users : registeredUsers) {
                if (users instanceof Company) {
                    Company company = (Company) users;

                    if (company.getPublishedProfile() == true) {
                        company.viewProfile();
                    }
                }
            }
        }
    }

    //Registro
    //Registrar usuarios
    public void registeredUsers() {
        //validar tipo de cuenta y llamar clases
        System.out.println("Registrando");
        menu.menuTypeAccount();
        int option = Integer.parseInt(input.nextLine());

        //Validamos tipo de cuenta
        if (option == 1) {
            //Empresas
            createCompany();
        } else if (option == 2) {
            createPerson();
        } else {
            System.out.println("El tipo de cuenta no es valido");
        }
    }

    //Registro de personas
    public void createPerson() {

        System.out.println("\nCreando cuenta personal \n");

        System.out.print("Nombre completo: ");
        String namePerson = input.nextLine();
        System.out.print("Edad: ");
        int age = Integer.parseInt(input.nextLine());
        System.out.print("Nacionalidad: ");
        String nationality = input.nextLine();
        System.out.print("Genero: ");
        String gender = input.nextLine();
        System.out.print("Numero de telefono: ");
        String phoneNumber = input.nextLine();
        System.out.print("Email: ");
        String email = input.nextLine();
        System.out.print("Años de experiencia laboral: ");
        int yearWorkExperience = Integer.parseInt(input.nextLine());
        System.out.print("Experiencia laboral: ");
        String workExperience = input.nextLine();
        System.out.print("Identificacion: ");
        int idPerson = Integer.parseInt(input.nextLine());
        System.out.print("Usuario: ");
        String userP = input.nextLine();
        System.out.print("Contrasena: ");
        String passwordP = input.nextLine();

        //Creamos un objeto de la clase Person
        Person person = new Person(
                userP,
                passwordP,
                namePerson,
                email,
                phoneNumber,
                age,
                nationality,
                gender,
                yearWorkExperience,
                workExperience,
                idPerson
        );

        //Guardamos los datos de la persona
        registeredUsers.add(person);
    }

    //Registro de empresas 
    public void createCompany() {

        //Cuenta empresarial
        System.out.println("\nCreando cuenta empresarial \n ");

        System.out.print("Nombre de la empresa: ");
        String nameCompany = input.nextLine();
        System.out.print("Email: ");
        String mailCompany = input.nextLine();
        System.out.print("Numero telefonico: ");
        String phoneNumber = input.nextLine();
        System.out.print("Ubicacion: ");
        String location = input.nextLine();
        System.out.print("Numero de empleados: ");
        int numEmployees = Integer.parseInt(input.nextLine());
        System.out.print("Descripcion de la empresa: ");
        String descriptionCompany = input.nextLine();
        System.out.print("Mision de la empresa: ");
        String missionCompany = input.nextLine();
        System.out.print("Vision de la empresa: ");
        String visionCompany = input.nextLine();
        System.out.print("Usuario: ");
        String userC = input.nextLine();
        System.out.print("Contrasena: ");
        String passwordC = input.nextLine();

        //Creamos un objeto de la clase Company
        Company company = new Company(
                userC,
                passwordC,
                nameCompany,
                mailCompany,
                phoneNumber,
                location,
                numEmployees,
                descriptionCompany,
                missionCompany,
                visionCompany
        );

        //Guardamos los datos de la empresa
        registeredUsers.add(company);
    }
}
