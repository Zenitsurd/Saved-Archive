package com.mycompany.talenhunt.v1;

import java.util.ArrayList;
import java.util.Scanner;

public class SystemManager {

    //Atributos
    private ArrayList<Users> registeredUsers;
    private Scanner input;
    private Menu menu = new Menu();

    //Metodo constructor
    public SystemManager() {
        this.registeredUsers = new ArrayList<>();
        this.input = new Scanner(System.in);
    }

    //Login
    public Users loginUsers() {
        //usuarios personas
        Person person1 = new Person(
                "userP1", "user123", "Alice Johnson", "alice.johnson@example.com",
                "1234567890", "Ingeniera de software", 30, "American", "Female", 5,
                "Software Developer at TechCorp, Project Manager at InnovateX", 1
        );

        Person person2 = new Person(
                "userP2", "user456", "Carlos Martínez", "carlos.martinez@example.com",
                "0987654321", "Data science", 28, "Mexican", "Male", 3,
                "Data Analyst at DataVision, Junior Data Scientist at InsightsLab", 2
        );

        Person person3 = new Person(
                "userP3", "user789", "Emma Li", "emma.li@example.com",
                "1122334455", "Ingeniero civil", 35, "Chinese", "Female", 8,
                "Senior UX Designer at CreateSpace, Lead Designer at PixelPerfect", 3
        );

        registeredUsers.add(person1);
        registeredUsers.add(person2);
        registeredUsers.add(person3);

        //usuarios empresas
        Company company1 = new Company(
                "userC1",
                "userC123",
                "Tech Solutions",
                "contact@techsolutions.com",
                "1234567890",
                "New York, USA",
                50,
                "We provide cutting-edge tech solutions.",
                "Empower innovation",
                "Become a global leader in tech."
        );

        Company company2 = new Company(
                "userC2",
                "userC456",
                "Green Energy Co.",
                "info@greenenergy.com",
                "0987654321",
                "San Francisco, USA",
                200,
                "Leading provider of renewable energy solutions.",
                "Sustainable energy for all",
                "Transform the world with green energy."
        );
        Company company3 = new Company(
                "user3",
                "password3",
                "Health Plus",
                "support@healthplus.com",
                "1122334455",
                "Chicago, USA",
                100,
                "Innovative health services for everyone.",
                "Care beyond boundaries",
                "Promote health and wellness worldwide."
        );

        //Guardamos los datos de la empresa
        registeredUsers.add(company1);
        registeredUsers.add(company2);
        registeredUsers.add(company3);

        //Recopilamos datos
        System.out.println(menu.alignCenter() + "    Iniciar Sesion \n");
        System.out.print("Usuario: ");
        String user = input.nextLine();
        System.out.print("Contrasena: ");
        String password = input.nextLine();

        if (!user.isEmpty() && !password.isEmpty()) { //Validamos que el usuario ingreso datos validos

            for (Users userData : registeredUsers) { //recorremos la lista para hacer la validacion de usuarios

                //Validamos de que usuario ingresado sea igual a algun usuario de la lista y lo mismo con el password
                if (userData.getUser().equals(user) && userData.getPassword().equals(password)) {
                    // si se cumple la condicion return los datos de este usuario
                    return userData;
                }
            }

            //si el usuario ingresado no existe en la lista entonces las credenciales son erroneas o el usuario no existe
            System.out.println("Credenciales incorrectas \n");
            return null;

        } else {

            System.out.println("Debe ingresar su usuario y/o contrasena \n");
            return null;
        }
    }

    //acciones de usuarios
    public void actionUsers() {

        //Guardamos los datos del usuario que se logueo
        Users userLogued = loginUsers();

        //validamos que el usuario ingresado sea valido
        if (userLogued != null) {
            //instance of para saber de que clase es este objeto
            if (userLogued instanceof Person) {
                System.out.println("\nBienvenido " + userLogued.getName());
                actionPerson(userLogued);
            } else if (userLogued instanceof Company) {
                System.out.println("\nBienvenida " + userLogued.getName());
                actionCompany(userLogued);
            }
        }
    }

    //Acciones que realiza la empresa
    public void actionCompany(Users user) {

        int on = 0;

        while (on != 4) {

            int option = 0, on2 = 0;

            while (on2 != 1) {
                try {
                    menu.menuCompany();
                    option = Integer.parseInt(input.nextLine());
                    on2 = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("Digite solo numeros");
                }
            }

            switch (option) {

                case 1:

                    int on3 = 0;

                    while (on3 != 3) {

                        int option1 = 0, on4 = 0;

                        while (on4 != 1) {

                            try {
                                menu.menuProfile();
                                option1 = Integer.parseInt(input.nextLine());
                                on4 = 1;
                            } catch (NumberFormatException ex) {
                                System.out.println("Digite solo numeros");
                            }
                        }

                        if (option1 == 1) {
                            viewMyProfileCompany(user);
                            on3 = 1;
                        } else if (option1 == 2) {
                            publishedProfileCompany(user);
                            on3 = 2;
                        } else if (option1 == 3) {
                            System.out.println("\nVolviendo al menu principal.");
                            on3 = 3;
                        } else {
                            System.out.println("Opcion no valida");
                        }

                    }
                    on = 1;
                    break;
                case 2:

                    int on5 = 0;

                    while (on5 != 5) {

                        int option2 = 0, on6 = 0;

                        while (on6 != 1) {
                            try {
                                menu.menuVacantCompany();
                                option2 = Integer.parseInt(input.nextLine());
                                on6 = 1;
                            } catch (NumberFormatException ex) {
                                System.out.println("Digite solo numeros");

                            }
                        }

                        switch (option2) {
                            case 1:
                                createVacancy(user);
                                on5 = 1;
                                break;
                            case 2:
                                publishedVacancy(user);
                                on5 = 2;
                                break;
                            case 3:
                                viewMyVacancies(user);
                                on5 = 3;
                                break;
                            case 4:
                                viewApplicants(user);
                                on5 = 4;
                                break;
                            case 5:
                                System.out.println("\nVolviendo al menu principal");
                                on5 = 5;
                                break;
                            default:
                                System.out.println("Opcion no valida");
                                break;
                        }
                    }
                    on = 2;
                    break;
                case 3:
                    viewProfilePerson(user);
                    on = 3;
                    break;
                case 4:
                    //salir
                    System.out.println("Sesion Cerrada");
                    on = 4;
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        }
    }

    //Acciones que realiza la persona
    public void actionPerson(Users user) {

        int on = 0;

        while (on != 4) {
            int option = 0, on1 = 0;

            while (on1 != 1) {
                try {
                    menu.menuPerson();
                    option = Integer.parseInt(input.nextLine());
                    on1 = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("Digite solo numeros");
                }
            }

            switch (option) {

                case 1:

                    int on2 = 0;

                    while (on2 != 3) {

                        int option1 = 0, on3 = 0;

                        while (on3 != 1) {
                            try {
                                menu.menuProfile();
                                option1 = Integer.parseInt(input.nextLine());
                                on3 = 1;
                            } catch (NumberFormatException ex) {
                                System.out.println("Digite solo numeros");
                            }
                        }

                        if (option1 == 1) {
                            viewMyProfilePerson(user);
                            on2 = 1;
                        } else if (option1 == 2) {
                            publishedProfilePerson(user);
                            on2 = 2;
                        } else if (option1 == 3) {
                            System.out.println("\nVolviendo al menu principal.");
                            on2 = 3;
                        } else {
                            System.out.println("Opcion no valida");
                        }
                    }
                    on = 1;
                    break;
                case 2:

                    int on4 = 0;

                    while (on4 != 3) {

                        int option2 = 0, on5 = 0;

                        while (on5 != 1) {
                            try {
                                menu.menuVacantPerson();
                                option2 = Integer.parseInt(input.nextLine());
                                on5 = 1;
                            } catch (NumberFormatException ex) {
                                System.out.println("Digite solo numeros");
                            }
                        }

                        if (option2 == 1) {
                            viewVacancyAvailable(user);
                            on4 = 1;
                        } else if (option2 == 2) {
                            postulation(user);
                            on4 = 2;
                        } else if (option2 == 3) {
                            System.out.println("\nVolviendo al menu principal");
                            on4 = 3;
                        } else {
                            System.out.println("Opcion no valida");
                        }
                    }
                    on = 2;
                    break;
                case 3:
                    viewProfileCompany(user);
                    on = 3;
                    break;
                case 4:
                    System.out.println("Sesion cerrada");
                    on = 4;
                    //salir
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;

            }
        }
    }

    //empresas
    //Perfil
    //ver perfil (empresa)
    public void viewMyProfileCompany(Users user) {

        if (user instanceof Company) {

            Company company = (Company) user;

            Vacancy vacancy1 = new Vacancy(
                    "Desarrollador Java",
                    "Desarrollador Junior",
                    "Empresa dedicada al desarrollo de software.",
                    "Ingeniería en Sistemas",
                    "1 año en desarrollo de aplicaciones",
                    "Lunes a Viernes, 9 AM - 5 PM",
                    30000.0,
                    "Ciudad de México",
                    "Seguro médico, capacitación constante",
                    "contacto1@empresa.com",
                    "Indefinido"
            );

            Vacancy vacancy2 = new Vacancy(
                    "Analista de Datos",
                    "Analista de Datos Senior",
                    "Empresa de consultoría en datos.",
                    "Licenciatura en Matemáticas o Estadística",
                    "3 años en análisis de datos",
                    "Lunes a Viernes, 10 AM - 7 PM",
                    60000.0,
                    "Monterrey",
                    "Flexibilidad horaria, bonos de desempeño",
                    "contacto2@empresa.com",
                    "Temporal"
            );

            Vacancy vacancy3 = new Vacancy(
                    "Gerente de Proyectos",
                    "Gerente de Proyectos IT",
                    "Empresa de tecnología en crecimiento.",
                    "Maestría en Administración o afín",
                    "5 años en gestión de proyectos",
                    "Lunes a Viernes, 8 AM - 5 PM",
                    80000.0,
                    "Guadalajara",
                    "Auto de la empresa, seguro de vida",
                    "contacto3@empresa.com",
                    "Indefinido"
            );

            company.addVacancies(vacancy1);
            company.addVacancies(vacancy2);
            company.addVacancies(vacancy3);

            vacancy1.setPublicVacancy(true);
            vacancy3.setPublicVacancy(true);
            //ver perfil
            System.out.println(menu.alignCenter() + "   ✿ Viendo el perfil ✿\n");
            System.out.println("Este es su perfil " + company.getName() + "\n");
            System.out.println(company.viewProfile());
        }
    }

    //Publicar perfil (empresa)
    public void publishedProfileCompany(Users user) {
        if (user instanceof Company) {
            Company company = (Company) user;
            //publicar perfil
            if (company.getPublishedProfile() != true) {
                company.setPublicProfile(true);
                System.out.println("\nSe ha publicado su perfil exitosamente");
            } else {
                System.out.println("\nSu perfil ya ha sido publicado, no lo puede publicar nuevamente");
            }

        }
    }

    //Vacantes
    //Metodo para crear (Vacantes) - empresas
    public void createVacancy(Users user) {

        Company company = (Company) user;
        //Crear mis vacantes
        System.out.println(menu.alignCenter() + "   ✿ Crear vacante ✿\n");
        System.out.print("Titulo de vacante : ");
        String titleVacancy = input.nextLine();
        System.out.print("Puesto de vacante : ");
        String puestoVacante = input.nextLine(); //pasar puesto vacante a ingles
        System.out.print("Descripcion de vacante : ");
        String descriptionCompany = input.nextLine();
        System.out.print("Formacion academica : ");// academicTraining
        String academicTraining = input.nextLine();
        System.out.print("Experiencia laboral : ");
        String experience = input.nextLine();
        System.out.print("Jornada laboral : "); //workingDay
        String workingDay = input.nextLine();

        int on = 0;
        double salary = 0;

        while (on != 1) {
            try {
                System.out.print("Salario (formatos aceptados 0.0 o 0): ");
                salary = Double.parseDouble(input.nextLine());
                on = 1;
            } catch (NumberFormatException ex) {
                System.out.println("Digite solo numeros o el formato adecuado");
            }
        }
        System.out.print("Ubicacion : ");
        String location = input.nextLine();
        System.out.print("Beneficios : ");
        String benefits = input.nextLine();
        System.out.print("Contacto : ");
        String contact = input.nextLine();
        System.out.print("Tipo de contrato : ");
        String typeOfContract = input.nextLine();

        //cast
        //Forzamos el contenido de usuario a convertirse en un objeto de la clase persona
        company.addVacancies(
                new Vacancy(
                        titleVacancy,
                        puestoVacante,
                        descriptionCompany,
                        academicTraining,
                        experience,
                        workingDay,
                        salary,
                        location,
                        benefits,
                        contact,
                        typeOfContract
                )
        );

        System.out.println("\nVacante creada exitosamente");
    }

    //metodo para publicar vacantes (empresa)
    public void publishedVacancy(Users user) {

        Company company = (Company) user;

        //Publicar vacantes
        System.out.println(menu.alignCenter() + "✿ Publicar vacante ✿ \n");

        if (company.validateVacancies() == true) {
            company.listMyVacancies();

            int id = 0, on = 0;

            while (on != 1) {
                try {
                    System.out.print("Ingrese el id de la vacante que desea publicar: ");
                    id = Integer.parseInt(input.nextLine());
                    on = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("Digite solo numeros");
                }
            }

            boolean idValidate = company.validatePublicVacancy(id);

            if (idValidate != true) {
                System.out.println("\nNo hay ninguna vacante con este identificador");
            }

        } else {
            System.out.println("No puede publicar vacantes si no ha creado una");
        }

    }

    //Metodo para ver vacantes (empresa)
    public void viewMyVacancies(Users user) {

        if (user instanceof Company) {
            Company company = (Company) user;
            if (company.validateVacancies() == true) {
                System.out.println(menu.alignCenter() + "   ✿ Viendo Vacantes ✿\n");
                company.viewMyVacancies();
            } else {
                System.out.println("No puede ver vacantes si no ha creado una");
            }
        }
    }

    //metodo para ver postulantes a vacantes (empresas)
    public void viewApplicants(Users user) {
        if (user instanceof Company) {

            Company company = (Company) user;

            if (company.validateVacancies() == true) {

                System.out.println(menu.alignCenter() + "   ✿ Viendo Postulantes ✿\n");

                company.listMyVacancies();

                int id = 0, on = 0;

                while (on != 1) {
                    try {
                        System.out.print("Ingrese el id de la vacante: ");
                        id = Integer.parseInt(input.nextLine());
                        on = 1;
                    } catch (NumberFormatException ex) {
                        System.out.println("Digite solo numeros");
                    }
                }

                boolean viewApplicants = company.viewApplicantsOfVacancy(id);

                if (viewApplicants != true) {
                    System.out.println("No hay una vacante con este id");
                }
            } else {
                System.out.println("\nNo puede ver postulantes a vacantes si no ha creado una");
            }
        }
    }

    //Perfiles de personas
    //Metodo para ver perfiles de personas (empresa)
    public void viewProfilePerson(Users user) {

        System.out.println(menu.alignCenter() + "   ✿ Perfiles De Personas ✿\n");

        boolean availableProfile = false;

        for (Users users : registeredUsers) {
            if (users instanceof Person) {
                Person person = (Person) users;
                if (person.getPublishedProfile() == true) {
                    System.out.println("Perfil de " + person.getName() + "\n");
                    System.out.println(person.viewProfile());
                    availableProfile = true;
                }
            }
        }

        if (availableProfile == false) {
            System.out.println("\nNo hay perfiles publicados");
        }
    }

    //Personas
    //Perfil
    //ver perfil (persona)
    public void viewMyProfilePerson(Users user) {
        if (user instanceof Person) {
            Person person = (Person) user;
            //ver perfil
            System.out.println(menu.alignCenter() + "  ✿ Viendo el perfil ✿\n");
            System.out.println("Este es su perfil " + person.getName() + "\n");
            System.out.println(person.viewProfile());

        }
    }

    //Publicar perfil (persona)
    public void publishedProfilePerson(Users user) {
        if (user instanceof Person) {
            Person person = (Person) user;

            //publicar perfil
            //validamos que el perfil no este publicado
            if (person.getPublishedProfile() != true) {
                person.setPublicProfile(true);
                System.out.println("\nSu perfil ha sido publicado");
            } else {
                System.out.println("\nNo puedes publicar tu perfil si ya ha sido publicado");
            }
        }
    }

    //Vacantes
    //Vacantes disponibles
    public void viewVacancyAvailable(Users user) {
        System.out.println(menu.alignCenter() + "*** Vacantes *** \n");

        boolean availableVacancies = false;

        for (Users users : registeredUsers) {
            if (users instanceof Company) {
                Company company = (Company) users;

                if (company.validateVacancies()) {
                    company.listVacancyToPerson();
                    availableVacancies = true;
                }
            }
        }

        if (availableVacancies) {

            int id = 0, on = 0;
            String viewVacancy = null;
            
            while (on != 1) {
                try {
                    System.out.print("Ingrese el id de la vacante para ver mas: ");
                    id = Integer.parseInt(input.nextLine());
                    on = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("Digite solo numeros");
                }
            }

            for (Users users : registeredUsers) {
                if (users instanceof Company) {
                    Company company = (Company) users;
                    
                    viewVacancy = company.showVacancies(id);
                    
                    if (viewVacancy != null){
                        break;
                    }
                }
            }
            
            if (viewVacancy == null){
                System.out.println("\nNo se encontro una vacante con este id");
            } else {
                System.out.println(viewVacancy);
            }
            
        } else {
            System.out.println("\nPor ahora no hay vacantes disponibles");
        }
    }

    //Postularse
    public void postulation(Users user) {

        //metodo cast para forzar el contenido de user a Person
        Person person = (Person) user;
        boolean availableVacancy = false; //para ver si hay vacantes

        System.out.println(menu.alignCenter() + "      ✿ Postularme ✿\n");

        for (Users users : registeredUsers) {
            if (users instanceof Company) {
                //metodo cast para forzar contenido de users a Company
                Company company = (Company) users;

                //validamos que exista una vacante
                if (company.validateVacancies() != false) {
                    company.listVacancyToPerson();
                    availableVacancy = true;
                }
            }
        }

        if (availableVacancy != false) {

            int id = 0, on = 0;

            while (on != 1) {
                try {
                    System.out.print("Ingrese el id de la vacante: ");
                    id = Integer.parseInt(input.nextLine());
                    on = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("Digite solo numeros");
                }
            }

            boolean postulate = false;

            for (Users users : registeredUsers) {

                if (users instanceof Company) {
                    //cast para forzar contenido de users a Company
                    Company company = (Company) users;
                    //Para validar que no este postulado
                    postulate = company.validatePostulate(person, id);

                    if (postulate != true) {
                        System.out.println(company.applicantsVacancy(id, person));
                        break;
                    } else {
                        System.out.println("\nNo puede postularse a la misma vacante dos veces");
                        break;
                    }
                }
            }

        } else {
            System.out.println("Por el momento no hay vacantes disponibles");
        }
    }

    //Ver perfiles de empresas
    //metodo para ver perfiles de empresas (PERSONAS)
    public void viewProfileCompany(Users user) {

        if (user instanceof Person) {

            boolean availableProfile = false;

            for (Users users : registeredUsers) {
                if (users instanceof Company) {
                    Company company = (Company) users;

                    if (company.getPublishedProfile() == true) {
                        System.out.println(company.viewProfile());
                        availableProfile = true;
                    }
                }
            }

            if (availableProfile != true) {
                System.out.println("\nNo hay perfiles de empresas publicados");
            }
        }
    }

    //Registro
    //Registrar usuarios
    public void registeredUsers() {

        int on = 0;

        while (on != 3) {

            int option = 0, on2 = 0;

            System.out.println(menu.alignCenter() + "          ✿ Registro ✿");

            while (on2 != 1) {
                try {
                    menu.menuTypeAccount();
                    option = Integer.parseInt(input.nextLine());
                    on2 = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("\nPorfavor ingrese solo numeros\n");
                }
            }

            //Validamos tipo de cuenta
            if (option == 1) {
                //Empresas
                createCompany();
                on = 1;
            } else if (option == 2) {
                //personas
                createPerson();
                on = 2;
            } else if (option == 3) {
                System.out.println("\nVolviendo a la pantalla principal");
                on = 3;
            } else {
                System.out.println("Opcion no valida");
            }

        }
    }

    //Registro de empresas 
    public void createCompany() {

        //Cuenta empresarial
        System.out.println(menu.alignCenter() + " ✿ Registro Cuenta Empresarial ✿ \n");

        System.out.print("Nombre de la empresa: ");
        String name = input.nextLine();
        System.out.print("Email: ");
        String mail = input.nextLine();
        System.out.print("Numero telefonico: ");
        String phoneNumber = input.nextLine();
        System.out.print("Ubicacion: ");
        String location = input.nextLine();
        int numEmployees = 0, on = 0;

        while (on != 1) {

            try {
                System.out.print("Numero de empleados: ");
                numEmployees = Integer.parseInt(input.nextLine());
                on = 1;
            } catch (NumberFormatException ex) {
                System.out.println("\nDigite numeros, no ingrese caracteres\n");
            }
        }

        System.out.print("Descripcion de la empresa: ");
        String description = input.nextLine();
        System.out.print("Mision de la empresa: ");
        String mission = input.nextLine();
        System.out.print("Vision de la empresa: ");
        String vision = input.nextLine();
        System.out.print("Usuario: ");
        String user = input.nextLine();
        System.out.print("Contrasena: ");
        String password = input.nextLine();

        //Guardamos los datos de la empresa
        registeredUsers.add(
                //Creamos un objeto de la clase Company
                new Company(
                        user,
                        password,
                        name,
                        mail,
                        phoneNumber,
                        location,
                        numEmployees,
                        description,
                        mission,
                        vision
                )
        );

        System.out.println("\nUsuario creado exitosamente");
    }

    //Registro de personas
    public void createPerson() {

        int on = 0;

        while (on != 2) {

            System.out.println(menu.alignCenter() + "   ✿ Registro Cuenta Personal ✿ \n");

            System.out.print("Nombre completo: ");
            String name = input.nextLine();
            int age = 0, on1 = 0;

            while (on1 != 1) {
                try {
                    System.out.print("Edad: ");
                    age = Integer.parseInt(input.nextLine());
                    on1 = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("\nDigite numeros, no ingrese caracteres\n");
                }
            }

            if (age < 18) {
                System.out.println("\nDebe ser mayor de edad. Volviendo al menu de registo");
                break;
            }

            System.out.print("Nacionalidad: ");
            String nationality = input.nextLine();
            System.out.print("Genero: ");
            String gender = input.nextLine();
            System.out.print("Numero de telefono: ");
            String phoneNumber = input.nextLine();
            System.out.print("Email: ");
            String email = input.nextLine();
            System.out.print("Titulo (en caso de tener 2 separe con una (,)): ");
            String title = input.nextLine();

            int yearWorkExperience = 0, on2 = 0;

            while (on2 != 1) {

                try {
                    System.out.print("Años de experiencia laboral: ");
                    yearWorkExperience = Integer.parseInt(input.nextLine());
                    on2 = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("\nDigite numeros, no ingrese caracteres\n");
                }
            }

            System.out.print("Experiencia laboral: ");
            String workExperience = input.nextLine();

            int numIdentity = 0, on3 = 0;

            while (on3 != 1) {

                try {
                    System.out.print("Numero de identificacion: ");
                    numIdentity = Integer.parseInt(input.nextLine());
                    on3 = 1;
                } catch (NumberFormatException ex) {
                    System.out.println("\nDigite numeros, no ingrese caracteres\n");
                }

            }

            System.out.print("Usuario: ");
            String user = input.nextLine();
            System.out.print("Contrasena: ");
            String password = input.nextLine();

            //Guardamos los datos de la persona
            registeredUsers.add(
                    //Creamos un objeto de la clase Person
                    new Person(
                            user,
                            password,
                            name,
                            email,
                            phoneNumber,
                            title,
                            age,
                            nationality,
                            gender,
                            yearWorkExperience,
                            workExperience,
                            numIdentity
                    )
            );

            System.out.println("\nUsuario creado exitosamente");

            on = 2;
        }
    }

}
