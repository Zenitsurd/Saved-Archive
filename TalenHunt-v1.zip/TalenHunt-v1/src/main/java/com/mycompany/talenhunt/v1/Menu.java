package com.mycompany.talenhunt.v1;

//En esta clase se encuentran los menus que se utilizaran en el programa
public class Menu {

    //Menu principal
    public void menuMain() {
        System.out.println("\n ✿  Bienvenido a TalentHunt ✿  \n");
        System.out.println("Opcion 1 | Iniciar sesion");
        System.out.println("Opcion 2 | Registrarse");
        System.out.println("Opcion 3 | Salir \n");
        System.out.print("Opcion: ");
    }

    //Menu tipos de cuentas
    public void menuTypeAccount() {
        System.out.println("\nEscoja el tipo de cuenta que desea crear. \n");
        System.out.println(" ✿  Tipo de cuenta  ✿  \n");
        System.out.println("Opcion 1 | Cuenta empresa");
        System.out.println("Opcion 2 | Cuenta personas \n");
        System.out.print("Opcion: ");
    }

    //Menu para empresas
    public void menuCompany() {
        System.out.println("\n ✿  Bienvenida Empresa ✿ \n");
        System.out.println("Opcion 1 | Perfil > ");
        System.out.println("Opcion 2 | Vacantes > ");
        System.out.println("Opcion 3 | Ver perfiles de personas ");
        System.out.println("Opcion 4 | Cerrar sesion");
    }

    //Menu para personas
    public void menuPerson() {
        System.out.println("\n  ✿  Bienvenido postulante ✿ \n");
        System.out.println("Opcion 1 | Perfil > ");
        System.out.println("Opcion 2 | Vacantes > ");
        System.out.println("Opcion 3 | Ver perfiles de empresas ");
        System.out.println("Opcion 4 | Cerrar sesion ");
    }

    //Menu de opciones de perfil
    public void menuProfile() {
        System.out.println("\n ✿  Perfil  ✿ \n");
        System.out.println("Opcion 1 | Ver perfil ");
        System.out.println("Opcion 2 | Publicar mi perfil ");
        System.out.println("Opcion 3 | Volver al menu principal \n");
    }
    
    //Menu de opciones de vacantes personas
    public void menuVacantPerson(){
        System.out.println("\n ✿  Vacantes  ✿ \n");
        System.out.println("Opcion 1 | Vacantes Disponibles ");
        System.out.println("Opcion 2 | Postularme ");
        System.out.println("Opcion 3 | Volver al menu principal ");
    }
    
    //Menu de opciones de vacantes Empresas
    public void menuVacantCompany(){
        System.out.println("\n ✿  Vacantes  ✿ \n");
        System.out.println("Opcion 1 | Crear Vacantes");
        System.out.println("Opcion 2 | Publicar Vacantes");
        System.out.println("Opcion 3 | Ver mis vacantes > ");
        System.out.println("Opcion 4 | Volver al menu principal");
    }
    
    //Menu de opciones de ver perfiles de empresas
    public void menuViewProfileCompany(){
        System.out.println("\n ✿  Ver perfiles de empresas ✿ \n");
        System.out.println("Opcion 1 | Ver perfiles ");
        System.out.println("Opcion 2 | Buscar perfiles ");
        System.out.println("Opcion 3 | Salir ");
    }
}
